
require('./server/.globals.js');
require('./server/.globals_mod.js');



