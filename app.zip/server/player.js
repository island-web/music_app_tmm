



CONTROLS.play_pause.addEventListener('click', function() {
    if (this.classList.contains('fa-play')) { this.classList = 'fa-solid fa-pause fa-fade' }
    else { this.classList = 'fa-solid fa-play' }
});

// Настраиваем наблюдение за изменениями атрибутов класса
observerPlayBtn.observe(CONTROLS.play_pause, { attributes: true });
